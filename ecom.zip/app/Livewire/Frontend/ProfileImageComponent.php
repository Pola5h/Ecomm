<?php

namespace App\Livewire\Frontend;

use Livewire\Component;

class ProfileImageComponent extends Component
{
    public function render()
    {
        return view('livewire.frontend.profile-image-component');
    }
}
