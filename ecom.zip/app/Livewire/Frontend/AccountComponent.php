<?php

namespace App\Livewire\Frontend;

use Livewire\Component;

class AccountComponent extends Component
{
    public function render()
    {
        return view('livewire.frontend.account-component');
    }
}
