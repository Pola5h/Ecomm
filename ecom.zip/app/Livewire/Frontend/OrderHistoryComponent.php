<?php

namespace App\Livewire\Frontend;

use Livewire\Component;

class OrderHistoryComponent extends Component
{
    public function render()
    {
        return view('livewire.frontend.order-history-component');
    }
}
