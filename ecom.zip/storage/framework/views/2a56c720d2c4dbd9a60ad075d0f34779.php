
<!-- google fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<!-- css link here  -->
<link rel="stylesheet" href="<?php echo e(asset ('frontend/./public/assets/plugins/css/swipper.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset ('frontend/./public/assets/plugins/css/select2.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset ('frontend/./public/css/tailwind.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset ('frontend/./public/css/styles.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset ('frontend/./public/css/responsive.css')); ?>"><?php /**PATH /home/polash/Laravel/Ecomm/resources/views/frontend/body/style.blade.php ENDPATH**/ ?>