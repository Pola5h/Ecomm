<?php $__env->startSection('admin'); ?>

<div class="page-body">
  <div class="container-xl d-flex flex-column justify-content-center">

    <div class="row row-cards">
      <div class="col-8">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">brand List</h3>
          </div>
          <div class="table-responsive">
            <table class="table table-vcenter table-mobile-md card-table">
              <thead>
                <tr>
                  <th>SL#</th>
                  <th>Image</th>
                  <th>Name</th>

                  <th class="w-1"></th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $brands): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($key + 1); ?></td>
                  <td data-label="Name">
                    <div class="d-flex py-1 align-items-center">
                      <span class="avatar me-2"
                        style="background-image: url('<?php echo e($brands->image ? asset('brand/' . $brands->image) : asset('../backend/assets/static/logo.svg')); ?>')"></span>

                    </div>
                  </td>

                  <td class="text-muted" data-label="Role">
                    <?php echo e($brands->name); ?> </td>
                  <td>
                    <div class="btn-list flex-nowrap">

                      <div class="dropdown">
                        <button class="btn dropdown-toggle align-text-top" data-bs-toggle="dropdown">
                          Actions
                        </button>
                        <div class="dropdown-menu dropdown-menu-end">
                          <a class="dropdown-item" href="<?php echo e(route('admin.brand.edit', $brands->slug)); ?>">
                            Edit
                          </a>
                          <form action="<?php echo e(route('admin.brand.destroy', $brands->slug)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="dropdown-item">
                              Delete
                            </button>
                          </form>
                        </div>
                      </div>
                    </div>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </tbody>
            </table>
          </div>
        </div>
      </div>
      <div class="col-4">

        <?php
        if (!empty($editData)) {
            $btn = 'Update';
        } else {
            $btn = 'Add';
        }
        ?>
        <?php if(empty($editData)): ?>

        <form method="post" class="card" action="<?php echo e(route('admin.brand.store')); ?>" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <div class="card-header">
            <h4 class="card-title">Add brand</h4>
          </div>
          <div class="card-body">
            <div class="row">
              <div class="col-xl-8">
                <div class="row">
                  <div class="col-md-6 col-xl-12">
                    <div class="mb-3">
                      <div class="col-auto mb-3">
                        <img src="" width="200" class="img-icon" />
                      </div>

                      <div class="col-auto mb-3">
                        <label class="form-label required">Image</label>

                        <input type="file" class="form-control" name="image" required />
                      </div>
                    </div>

                    <div class="mb-3">
                      <label class="form-label required">Name</label>
                      <input type="text" class="form-control" name="name" placeholder="Required..." />
                    </div>
                    

                  </div>

                </div>
              </div>

            </div>
          </div>
          <div class="card-footer text-end">
            <div class="d-flex">
              <button type="submit" class="btn btn-primary ms-auto">
                <?php echo e($btn); ?> </button>
            </div>
          </div>
        </form>

        <?php else: ?>

        <form method="post" class="card" action="<?php echo e(route('admin.brand.update',$editData->slug)); ?>"
          enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
          <div class="card-header">
            <h4 class="card-title">Edit brand</h4>
          </div>
          <div class="card-body">
            <div class="row">
              <div class="col-xl-8">
                <div class="row">
                  <div class="col-md-6 col-xl-12">

                    <div class="mb-3">
                      <div class="col-auto mb-3">
                        <img src="<?php echo e(asset('brand/' . $editData->image)); ?>" width="200" class="img-icon" />
                      </div>

                      <div class="col-auto mb-3">
                        <label class="form-label">Image</label>

                        <input type="file" class="form-control" name="image" />
                      </div>
                    </div>

                    <div class="mb-3">
                      <label class="form-label required">Name</label>
                      <input type="text" class="form-control"
                        value="<?php echo e(!empty($editData->name) ? $editData->name : ''); ?>" name="name"
                        placeholder="Required..." />
                    </div>
                    



                  </div>

                </div>
              </div>

            </div>
          </div>
          <div class="card-footer text-end">
            <div class="d-flex">
              <button type="submit" class="btn btn-primary ms-auto">
                <?php echo e($btn); ?>

              </button>
            </div>
          </div>
        </form>

        <?php endif; ?>

      </div>
    </div>
  </div>
</div>
<script>
  const fileInput = document.querySelector('input[type="file"]');
  const imgPreview = document.querySelector('.col-auto img');

  // Get the existing image source, if any.
  const existingImageSrc = imgPreview.getAttribute('src');

  // Listen for the change event on the file input field.
  fileInput.addEventListener('change', function() {
      // If the user has selected an image, preview it.
      if (fileInput.files.length > 0) {
          const fileReader = new FileReader();
          fileReader.onload = function() {
              imgPreview.src = fileReader.result;
          };
          fileReader.readAsDataURL(fileInput.files[0]);
      } else {
          // If the user has not selected an image, show the existing image or the default image.
          imgPreview.src = existingImageSrc || '<?php echo e(URL::asset('../backend/assets/static/logo.svg')); ?>';
      }
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/polash/Laravel/Ecomm/resources/views/admin/brand/index_brand.blade.php ENDPATH**/ ?>