<div class="box xl:w-[536px]">
    <div class="w-full ">
      
        <div class="p-6">
            <!--[if BLOCK]><![endif]--><?php if(Session::has ('success_message')): ?>

            <div class="alert alert-success">
                <strong>Success | <?php echo e(Session::get('success_message')); ?></strong>
            </div>
            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
            <form action="<?php echo e(route('user.profile.update')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('POST'); ?>
            
                <h2 class="text-start xl:text-2xl acc-title text-[22px] text-[#272343] font-medium mb-6 font-display">
                    Account Information</h2>

                    <div class="w-full  mb-5">
                        <input type="text" name="name" placeholder="Input name" value="<?php echo e(old('name', $user->name ?? '')); ?>"
                               class="input-box focus:outline-none focus:ring-2 focus:ring-accents font-display transition duration-300 ease-in-out">
                    </div>
                <div class="flex flex-col sm:flex-row gap-5 items-center mb-5">

                    <div class="w-full">
                        <input type="email" name="email" placeholder="Input email" value="<?php echo e(old('email', $user->email ?? '')); ?>"
                               class="input-box focus:outline-none focus:ring-2 focus:ring-accents font-display transition duration-300 ease-in-out">
                    </div>
                    <div class="w-full">
                        <input type="text" name="phone" placeholder="Input phone number" value="<?php echo e(old('phone', $user->phone ?? '')); ?>"
                               class="input-box focus:outline-none focus:ring-2 focus:ring-accents font-display transition duration-300 ease-in-out">
                    </div>
                </div>

                    <div class="w-full mb-5">
                        <textarea name="address" placeholder="Input Your address" class="input-box focus:outline-none focus:ring-2 focus:ring-accents font-display transition duration-300 ease-in-out"><?php echo e(old('address', $user->address ?? '')); ?></textarea>
                    </div>
                    

                  
                
                <button type="submit" class="btn-primary">Save Changes</button>
            </form>
            



        </div>
    </div>
</div><?php /**PATH /home/polash/Laravel/Ecomm/resources/views/livewire/frontend/account-setting-component.blade.php ENDPATH**/ ?>