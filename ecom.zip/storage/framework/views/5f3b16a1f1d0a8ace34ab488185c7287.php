<!doctype html>

<html lang="en">

<head>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
	<meta http-equiv="X-UA-Compatible" content="ie=edge" />
	<title><?php echo $__env->yieldContent('title', 'DashBoard'); ?></title>
	<!-- CSS Style -->
	<?php echo $__env->make('admin.body.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

</head>

<body>
	<script src="<?php echo e(URL::asset('../backend/assets/dist/js/demo-theme.min.js?1684106062')); ?>"></script>
	<div class="page">
		<!-- Sidebar -->
		<?php echo $__env->make('admin.body.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<!-- Navbar -->
		<?php echo $__env->make('admin.body.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<div class="page-wrapper">
			<?php echo $__env->yieldContent('admin'); ?>
			<!-- Footer -->
			<?php echo $__env->make('admin.body.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</div>
	</div>
	<!-- JS Scripts -->
	<?php echo $__env->make('admin.body.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



</body>

</html><?php /**PATH /home/polash/Laravel/Ecomm/resources/views/admin/master.blade.php ENDPATH**/ ?>