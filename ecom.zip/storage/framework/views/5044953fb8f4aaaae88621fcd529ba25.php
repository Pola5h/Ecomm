     <!-- Account Setting Start -->
     <div id="account_settings">
        <div class="container px-3 md:px-5 xl:px-0 py-10">
            <div class="accout-setting flex flex-col xl:flex-row gap-6">
                <!-- account inforamation start -->
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('frontend.account-setting-component');

$__html = app('livewire')->mount($__name, $__params, '1Iy6ChQ', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

                <!-- account inforamation end -->

                <div class="flex flex-col md:flex-row gap-6">
                    <!-- user password change start -->
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('frontend.user-password-component');

$__html = app('livewire')->mount($__name, $__params, 'C8Lgink', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

                    <!-- user password change end -->

                    <!-- user profile change start -->
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('frontend.profile-image-component');

$__html = app('livewire')->mount($__name, $__params, 'BBm3ljp', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

                    <!-- user profile change end -->
                </div>

            </div>
        </div>
    </div>
    <!-- Account Setting End -->
<?php /**PATH /home/polash/Laravel/Ecomm/resources/views/livewire/frontend/account-component.blade.php ENDPATH**/ ?>