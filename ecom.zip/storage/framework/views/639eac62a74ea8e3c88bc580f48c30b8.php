<div>
    <!-- Breadcrumb Start -->
    <div class="breadcrumb">
        <div class="container px-3 md:px-5 xl:px-0">
            <div class="flex items-center gap-1 py-[1.5px]">
                <a href="#" class="text-[14px] font-normal leading-[110%] text-dark-gray">Home</a>

                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M7.125 5.25L10.875 9L7.125 12.75" stroke="#636270" stroke-linecap="round"
                        stroke-linejoin="round" />
                </svg>

                <span
                    class="text-[14px] font-medium leading-[110%] font-display text-gray-black inline-block">Shop</span>
            </div>

            <h2 class="pt-[13.5px] text-2xl font-semibold text-gray-black font-display">Shop</h2>
        </div>
    </div>
    <!-- Breadcrumb End -->

    <!-- product List Start -->
    <section class="">
      

        <div class="product-list-area shadow-[inset_0px_1px_0px_#E1E3E6]">
            <div class="container px-3 md:px-5 xl:px-0">
                <div class="products-wrapper py-6 xl:grid-cols-4 sm:grid-cols-2 md:grid-cols-3 grid grid-cols-1 gap-6">


                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $isInWishlist = \App\Models\WishList::where('user_id', auth()->id())
                    ->where('product_id', $product->id)
                    ->exists();
                    ?>

                    <div class="product-card">
                        <a href="<?php echo e(route('product',['slug'=>$product->slug])); ?>">
                            <div class="product-thumb">
                                <img src="<?php echo e(asset('product/thumbnail/'.$product->thumbnail)); ?>" alt="">
                                <span class="badge new">New</span>
                            </div>
                            <div class="product-info">
                                <div>
                                    <h2 class="product-name"><?php echo e($product->name); ?></h2>
                                    <h3 class="product-price"><?php echo e($product->price); ?></h3>
                                </div>
                                
                            </div>
                        </a>
                        

                    </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->


                </div>
            
                    
            </div>
        </div>
    </section>
    <!-- product List End -->
</div><?php /**PATH /home/polash/Laravel/Ecomm/resources/views/livewire/frontend/search-component.blade.php ENDPATH**/ ?>