






<!doctype html>
<!--
* Tabler - Premium and Open Source dashboard template with responsive and high quality UI.
* @version 1.0.0-beta19
* @link https://tabler.io
* Copyright 2018-2023 The Tabler Authors
* Copyright 2018-2023 codecalm.net Paweł Kuna
* Licensed under MIT (https://github.com/tabler/tabler/blob/master/LICENSE)
-->
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>Reset Password</title>
    <!-- CSS files -->
    <link href="<?php echo e(URL::asset('../backend/assets/dist/css/tabler.min.css?1684106062')); ?>" rel="stylesheet" />
    <link href="<?php echo e(URL::asset('../backend/assets/dist/css/tabler-flags.min.css?1684106062')); ?>" rel="stylesheet" />
    <link href="<?php echo e(URL::asset('../backend/assets/dist/css/tabler-payments.min.css?1684106062')); ?>" rel="stylesheet" />
    <link href="<?php echo e(URL::asset('../backend/assets/dist/css/tabler-vendors.min.css?1684106062')); ?>" rel="stylesheet" />
    <link href="<?php echo e(URL::asset('../backend/assets/dist/css/demo.min.css?1684106062')); ?>" rel="stylesheet" />
    <style>
        @import url('https://rsms.me/inter/inter.css');

        :root {
            --tblr-font-sans-serif: 'Inter Var', -apple-system, BlinkMacSystemFont, San Francisco, Segoe UI, Roboto, Helvetica Neue, sans-serif;
        }

        body {
            font-feature-settings: "cv03", "cv04", "cv11";
        }
    </style>
</head>

<body class=" d-flex flex-column">
    <script src="./dist/js/demo-theme.min.js?1684106062"></script>
    <div class="page page-center">
        <div class="container container-tight py-4">
            <div class="text-center mb-4">
                <a href="." class="navbar-brand navbar-brand-autodark"><img
                        src="<?php echo e(URL::asset('../backend/assets/static/logo.svg')); ?>" height="36" alt=""></a>
            </div>
            <div class="card card-md">
                <div class="card-body">
                    <h2 class="h2 text-center mb-4">Reset your Password</h2>
                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-session-status','data' => ['class' => 'mb-4','status' => session('status')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('auth-session-status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4','status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('status'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

                    <form method="POST" action="<?php echo e(route('password.email')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label class="form-label">Email address</label>
                            <input type="email" name="email" class="form-control" placeholder="your@email.com" required>
                        </div>

                        <?php if($errors->has('email')): ?>
                        <div class="alert alert-danger">
                            <?php echo e($errors->first('email')); ?>

                        </div>
                        <?php endif; ?>

               
                        <div class="form-footer">
                            <button type="submit" class="btn btn-primary w-100">Submit</button>
                        </div>

                        
                        <script>
                            document.querySelector('.input-group-text a').addEventListener('mousedown', function() {
                                document.getElementById('passwordInput').type = 'text';
                            });

                            document.querySelector('.input-group-text a').addEventListener('mouseup', function() {
                                document.getElementById('passwordInput').type = 'password';
                            });
                        </script>

                    </form>

                </div>
              
            </div>
            <div class="text-center text-muted mt-3">
                Don't have account yet? <a href="<?php echo e(URL('login')); ?>" tabindex="-1">Login</a>
            </div>
        </div>
    </div>
    <!-- Libs JS -->
    <!-- Tabler Core -->
    <script src="<?php echo e(URL::asset('../backend/assets/dist/js/tabler.min.js?1684106062')); ?>" defer></script>
    <script src="<?php echo e(URL::asset('../backend/assets/dist/js/demo.min.js?1684106062')); ?>" defer></script>

</body>

</html>
















<?php /**PATH /home/polash/Laravel/Ecomm/resources/views/auth/forgot-password.blade.php ENDPATH**/ ?>