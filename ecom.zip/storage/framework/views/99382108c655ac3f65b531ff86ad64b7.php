<?php $__env->startSection('admin'); ?>

<div class="page-body">
  <div class="container-xl d-flex flex-column justify-content-center">

    <div class="row row-cards">
      <div class="col-8">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Testimonial List</h3>
          </div>
          <div class="table-responsive">
            <table class="table table-vcenter table-mobile-md card-table">
              <thead>
                <tr>
                  <th>SL#</th>
                  <th>Image</th>
                  <th>Name</th>
                  <th>Designation</th>
                  <th class="w-1"></th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $testimonials): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($key + 1); ?></td>
                  <td data-label="Name">
                    <div class="d-flex py-1 align-items-center">
                      <span class="avatar me-2"
                        style="background-image: url('<?php echo e($testimonials->image ? asset('testimonial/' . $testimonials->image) : asset('../backend/assets/static/logo.svg')); ?>')"></span>

                    </div>
                  </td>

                  <td class="text-muted" data-label="Role">
                    <?php echo e($testimonials->client_name); ?> </td>
                  <td>
                    <td class="text-muted" data-label="Role">
                      <?php echo e($testimonials->designation); ?> </td>
                    <td>
                    <div class="btn-list flex-nowrap">

                      <div class="dropdown">
                        <button class="btn dropdown-toggle align-text-top" data-bs-toggle="dropdown">
                          Actions
                        </button>
                        <div class="dropdown-menu dropdown-menu-end">
                          <a class="dropdown-item" href="<?php echo e(route('admin.testimonial.edit', $testimonials->id)); ?>">
                            Edit
                          </a>
                          <form action="<?php echo e(route('admin.testimonial.destroy', $testimonials->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="dropdown-item">
                              Delete
                            </button>
                          </form>
                        </div>
                      </div>
                    </div>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </tbody>
            </table>
          </div>
        </div>
      </div>
      <div class="col-4">

        <?php
        if (!empty($editData)) {
            $btn = 'Update';
        } else {
            $btn = 'Add';
        }
        ?>
        <?php if(empty($editData)): ?>

        <form method="post" class="card" action="<?php echo e(route('admin.testimonial.store')); ?>" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <div class="card-header">
            <h4 class="card-title">Add testimonial</h4>
          </div>
          <div class="card-body">
            <div class="row">
              <div class="col-xl-8">
                <div class="row">
                  <div class="col-md-6 col-xl-12">
                    <div class="mb-3">
                      <div class="col-auto mb-3">
                        <img src="" width="200" class="img-icon" />
                      </div>

                      <div class="col-auto mb-3">
                        <label class="form-label required">Client Image</label>

                        <input type="file" class="form-control" name="image" required />
                      </div>
                    </div>

                    <div class="mb-3">
                      <label class="form-label required">Name</label>
                      <input type="text" class="form-control" name="name" placeholder="Required..." />
                    </div>
                    <div class="mb-3">
                      <label class="form-label required">Designation</label>
                      <input type="text" class="form-control" name="designation" placeholder="Required..." />
                    </div>
                    <div class="mb-3">
                      <label class="form-label required">Testimonial</label>
                      <textarea id="tinymce-mytextarea" name="testimonial"></textarea>

                    </div>

                  </div>

                </div>
              </div>

            </div>
          </div>
          <div class="card-footer text-end">
            <div class="d-flex">
              <button type="submit" class="btn btn-primary ms-auto">
                <?php echo e($btn); ?> </button>
            </div>
          </div>
        </form>

        <?php else: ?>

        <form method="post" class="card" action="<?php echo e(route('admin.testimonial.update',$editData->id)); ?>"
          enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
          <div class="card-header">
            <h4 class="card-title">Edit testimonial</h4>
          </div>
          <div class="card-body">
            <div class="row">
              <div class="col-xl-8">
                <div class="row">
                  <div class="col-md-6 col-xl-12">

                    <div class="mb-3">
                      <div class="col-auto mb-3">
                        <img src="<?php echo e(asset('testimonial/' . $editData->image)); ?>" width="200" class="img-icon" />
                      </div>

                      <div class="col-auto mb-3">
                        <label class="form-label">Client Image</label>

                        <input type="file" class="form-control" name="image" />
                      </div>
                    </div>

                    <div class="mb-3">
                      <label class="form-label required">Name</label>
                      <input type="text" class="form-control"
                        value="<?php echo e(!empty($editData->client_name) ? $editData->client_name : ''); ?>" name="name"
                        placeholder="Required..." />
                    </div>
                    <div class="mb-3">
                      <label class="form-label required">Designation</label>
                      <input type="text" class="form-control"
                        value="<?php echo e(!empty($editData->designation) ? $editData->designation : ''); ?>" name="name"
                        placeholder="Required..." />
                    </div>
                    <div class="mb-3">
                      <label class="form-label required">Testimonial</label>

                      <textarea id="tinymce-mytextarea2" name="description"><?php echo isset($editData->testimonial) ? $editData->testimonial : ''; ?></textarea>

                    </div> 



                  </div>

                </div>
              </div>

            </div>
          </div>
          <div class="card-footer text-end">
            <div class="d-flex">
              <button type="submit" class="btn btn-primary ms-auto">
                <?php echo e($btn); ?>

              </button>
            </div>
          </div>
        </form>

        <?php endif; ?>

      </div>
    </div>
  </div>
</div>
<script>
  const fileInput = document.querySelector('input[type="file"]');
  const imgPreview = document.querySelector('.col-auto img');

  // Get the existing image source, if any.
  const existingImageSrc = imgPreview.getAttribute('src');

  // Listen for the change event on the file input field.
  fileInput.addEventListener('change', function() {
      // If the user has selected an image, preview it.
      if (fileInput.files.length > 0) {
          const fileReader = new FileReader();
          fileReader.onload = function() {
              imgPreview.src = fileReader.result;
          };
          fileReader.readAsDataURL(fileInput.files[0]);
      } else {
          // If the user has not selected an image, show the existing image or the default image.
          imgPreview.src = existingImageSrc || '<?php echo e(URL::asset('../backend/assets/static/logo.svg')); ?>';
      }
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/polash/Laravel/Ecomm/resources/views/admin/others/index_testimonial.blade.php ENDPATH**/ ?>