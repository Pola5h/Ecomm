<!-- CSS files -->
<link href="<?php echo e(URL::asset('../backend/assets/dist/css/tabler.min.css?1684106062')); ?>" rel="stylesheet" />
<link href="<?php echo e(URL::asset('../backend/assets/dist/css/tabler-flags.min.css?1684106062')); ?>" rel="stylesheet" />
<link href="<?php echo e(URL::asset('../backend/assets/dist/css/tabler-payments.min.css?1684106062')); ?>" rel="stylesheet" />
<link href="<?php echo e(URL::asset('../backend/assets/dist/css/tabler-vendors.min.css?1684106062')); ?>" rel="stylesheet" />
<link href="<?php echo e(URL::asset('../backend/assets/dist/css/demo.min.css?1684106062')); ?>" rel="stylesheet" />
<link href="<?php echo e(URL::asset('../backend/assets/dist/css/tabler.min.css?1684106062')); ?>" rel="stylesheet" />
<link href="<?php echo e(URL::asset('../backend/assets/dist/css/tabler-flags.min.css?1684106062')); ?>" rel="stylesheet" />
<link href="<?php echo e(URL::asset('../backend/assets/dist/css/tabler-payments.min.css?1684106062')); ?>" rel="stylesheet" />
<link href="<?php echo e(URL::asset('../backend/assets/dist/css/tabler-vendors.min.css?1684106062')); ?>" rel="stylesheet" />
<link href="<?php echo e(URL::asset('../backend/assets/dist/css/demo.min.css?1684106062')); ?>" rel="stylesheet" />

<!-- Include jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- Include Dropify CSS and JS -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/Dropify/0.2.2/css/dropify.min.css" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/Dropify/0.2.2/js/dropify.min.js"></script>
<!--ckeditor 5 -->
<script src="https://cdn.ckeditor.com/ckeditor5/40.0.0/classic/ckeditor.js"></script>




<style>
	@import url('https://rsms.me/inter/inter.css');

	:root {
		--tblr-font-sans-serif: 'Inter Var', -apple-system, BlinkMacSystemFont, San Francisco, Segoe UI, Roboto, Helvetica Neue, sans-serif;
	}

	body {
		font-feature-settings: "cv03", "cv04", "cv11";
	}
	.ck-editor__editable{
		height: 250px;
	}
	
</style><?php /**PATH /home/polash/Laravel/Ecomm/resources/views/admin/body/style.blade.php ENDPATH**/ ?>