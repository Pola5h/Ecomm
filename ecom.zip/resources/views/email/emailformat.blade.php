<p>Name: {{$emailData->name}}</p>
<p>email: {{$emailData->email}}</p>
<p>Message: {{$emailData->message}}</p>